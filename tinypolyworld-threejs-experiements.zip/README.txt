A Pen created at CodePen.io. You can find this one at https://codepen.io/prabhatpathania/pen/aYjaby.

 My First Three.js project - based on the fantastic tutorial by Karim Maaloul - https://tympanus.net/codrops/2016/04/26/the-aviator-animating-basic-3d-scene-threejs/

Lots of optimisation still to be made on this,  but a fun introduction!
